<?php 
	include 'connect.php';

	if (isset($_POST['submit'])) {
		$name = $_POST['name'];
		$name = filter_var($name, FILTER_SANITIZE_STRING);
		$email = $_POST['email'];
		$email = filter_var($email, FILTER_SANITIZE_STRING);
		$pass = sha1($_POST['pass']);
		$pass = filter_var($pass, FILTER_SANITIZE_STRING);
		$cpass = sha1($_POST['cpass']);
		$cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

		$select_users = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
		$select_users->execute([$email]);

		if ($select_users->rowCount() > 0) {
			$message[] = 'email already exist';
		}elseif ($pass != $cpass) {
			$message[] = 'confirm password not matched';
		}else{
			$insert_user = $conn->prepare("INSERT INTO `users`(name, email, password) VALUES(?,?,?)");
			$insert_user->execute([$name, $email, $cpass]);
			if ($insert_user) {
				$fetch_user = $conn->prepare("SELECT * FROM `users` WHERE email=? AND password=?");
				$fetch_user->execute([$email, $cpass]);
				$row = $fetch_user->fetch(PDO::FETCH_ASSOC);
				if ($fetch_user->rowCount() > 0) {
					// 60*60*24 = 86400 sec which is equal to 1day
					//to set cookies for 1 month use 60*60*24*30
					setcookie('user_id', $row['id'], time() + 60*60*24, '/');
					header('location:home.php');
				}
			}
		}

	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>register</title>
	<!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
   <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<section>
		<div class="box">
			<?php 
				if (isset($message)) {
					foreach ($message as $message) {
						echo '
							<div class="message">
								<span>'.$message.'</span>
								<i class="fas fa-times" onclick="this.parentElement.remove();"></i>
							</div>
						';
					}
				}
			?> 
			<div class="square" style="--i:0;"></div>	
			<div class="square" style="--i:1;"></div>
			<div class="square" style="--i:2;"></div>
			<div class="square" style="--i:3;"></div>
			<div class="square" style="--i:4;"></div>
			<div class="square" style="--i:5;"></div>

			<div class="container">
				<div class="form">
					<h2>register now</h2>
					<form action="" method="post">
						<div class="inputBx">
							<label>user name</label>
							<input type="text" name="name" maxlength="20" required>
						</div>
						<div class="inputBx">
							<label>user email</label>
							<input type="email" name="email" maxlength="50" required>
						</div>
						<div class="inputBx">
							<label>user password</label>
							<input type="password" name="pass" maxlength="50" required>
						</div>
						<div class="inputBx">
							<label>confirm password</label>
							<input type="password" name="cpass" maxlength="50" required>
						</div>
						<input type="submit" name="submit" value="register now" class="btn">
					</form>
					<p>already have an account <a href="login.php">login now</a></p>
				</div>
			</div>
			
		</div>
	</section>
</body>
</html>