<?php 
	include 'connect.php';

	if (isset($_POST['submit'])) {
		
		$email = $_POST['email'];
		$email = filter_var($email, FILTER_SANITIZE_STRING);
		$pass = sha1($_POST['pass']);
		$pass = filter_var($pass, FILTER_SANITIZE_STRING);
		

		$select_users = $conn->prepare("SELECT * FROM `users` WHERE email = ? AND password = ?");
		$select_users->execute([$email, $pass]);
		$row = $select_users->fetch(PDO::FETCH_ASSOC);

		if ($select_users->rowCount() > 0) {
			setcookie('user_id', $row['id'], time() + 60*60*24, '/');
			header("location:home.php");
		}else{
			$message[] = 'incorrect email or password';
		}

	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>register</title>
	<!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
   <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<section>
		<div class="box">
			<?php 
				if (isset($message)) {
					foreach ($message as $message) {
						echo '
							<div class="message">
								<span>'.$message.'</span>
								<i class="fas fa-times" onclick="this.parentElement.remove();"></i>
							</div>
						';
					}
				}
			?> 
			<div class="square" style="--i:0;"></div>	
			<div class="square" style="--i:1;"></div>
			<div class="square" style="--i:2;"></div>
			<div class="square" style="--i:3;"></div>
			<div class="square" style="--i:4;"></div>
			<div class="square" style="--i:5;"></div>

			<div class="container">
				<div class="form">
					<h2>login now</h2>
					<form action="" method="post">
						
						<div class="inputBx">
							<label>user email</label>
							<input type="email" name="email" maxlength="50" required>
						</div>
						<div class="inputBx">
							<label>user password</label>
							<input type="password" name="pass" maxlength="50" required>
						</div>
						
						<input type="submit" name="submit" value="login now" class="btn">
					</form>
					<p>do not have an account <a href="register.php">register now</a></p>
				</div>
			</div>
			
		</div>
	</section>
</body>
</html>