<?php 
	$db_name = 'mysql:host=localhost;dbname=login_db';
	$user_name = 'root';
	$user_password = '';

	$conn = new PDO($db_name, $user_name, $user_password);
	if (!$conn) {
		echo "did not connected";
	}
?>